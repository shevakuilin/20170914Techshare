//
//  MaterialManage.h
//  ARSolarSystem
//
//  Created by ShevaKuilin on 2017/9/12.
//  Copyright © 2017年 ShevaKuilin. All rights reserved.
//

#ifndef MaterialManage_h
#define MaterialManage_h

#define IMAGE_CLOUDSTRANSPARENCY_MINI   @"art.scnassets/earth/cloudsTransparency-mini.png"
#define IMAGE_CLOUDSTRANSPARENCY        @"art.scnassets/earth/cloudsTransparency.png"
#define IMAGE_EARTH_BUMP                @"art.scnassets/earth/earth-bump.png"
#define IMAGE_EARTH_DIFFUSE_MINI        @"art.scnassets/earth/earth-diffuse-mini.jpg"
#define IMAGE_EARTH_DIFFUSE             @"art.scnassets/earth/earth-diffuse.jpg"
#define IMGAE_EARTH_EMISSIVE_MINI       @"art.scnassets/earth/earth-emissive-mini.jpg"
#define IMAGE_EARTH_EMISSIVE_MINI2      @"art.scnassets/earth/earth-emissive-mini2.jpg"
#define IMAGE_EARTH_EMISSIVE            @"art.scnassets/earth/earth-emissive.jpg"
#define IMAGE_EARTH_REFLECTIVE          @"art.scnassets/earth/earth-reflective.jpg"
#define IMAGE_EARTH_SPECULAR_MINI       @"art.scnassets/earth/earth-specular-mini.jpg"
#define IMAGE_EARTH_SPECULAR            @"art.scnassets/earth/earth-specular.jpg"
#define IMAGE_JUPITER_LOOP              @"art.scnassets/earth/jupiter_loop.png"
#define IMAGE_JUPITER                   @"art.scnassets/earth/jupiter.jpg"
#define IMAGE_MARS                      @"art.scnassets/earth/mars.jpg"
#define IMAGE_MERCURY                   @"art.scnassets/earth/mercury.jpg"
#define IMAGE_MOON                      @"art.scnassets/earth/moon.jpg"
#define IMAGE_NEPTUNE_LOOP              @"art.scnassets/earth/neptune_loop.png"
#define IMAGE_NEPTUNE                   @"art.scnassets/earth/neptune.jpg"
#define IMAGE_ORBIT                     @"art.scnassets/earth/orbit.png"
#define IMAGE_ORBIT1                    @"art.scnassets/earth/orbit1.png"
#define IMAGE_PLUTO                     @"art.scnassets/earth/pluto.jpg"
#define IMAGE_SATURN_CLOUD              @"art.scnassets/earth/saturn_cloud.png"
#define IMAGE_SATURN_LOOP               @"art.scnassets/earth/saturn_loop.png"
#define IMAGE_SATURN                    @"art.scnassets/earth/saturn.jpg"
#define IMAGE_SUN_HALO                  @"art.scnassets/earth/sun-halo.png"
#define IMAGE_SUN                       @"art.scnassets/earth/sun.jpg"
#define IMAGE_URANUS_LOOP               @"art.scnassets/earth/uranus_loop.png"
#define IMAGE_URANUS                    @"art.scnassets/earth/uranus.jpg"
#define IMAGE_VENUS                     @"art.scnassets/earth/venus.jpg"



#endif /* MaterialManage_h */
