//
//  ViewController.m
//  ARSolarSystem
//
//  Created by ShevaKuilin on 2017/9/11.
//  Copyright © 2017年 ShevaKuilin. All rights reserved.
//

#import "ViewController.h"
// 3D游戏框架
#import <SceneKit/SceneKit.h>
// ARKit框架
#import <ARKit/ARKit.h>
// 素材宏
#import "MaterialManage.h"

// 静态变量
NSString *const ANIMATION_ROTATION_KEY = @"rotation";                           // 旋转动画Key
NSString *const ANIMATION_CONTENTSTRANSFORM_KEY = @"contentsTransform";         // 内容变形动画Key
NSString *const ANIMATION_SUN_TEXTURE = @"sun-texture";                         // 太阳表面熔岩效果
NSString *const ANIMATION_SUN_COLORING = @"sun-coloring";                       // 太阳熔岩效果着色
NSString *const ROTATION_MOON = @"moon rotation";                               // 月球自转
NSString *const ROTATION_MERCURY_AROUND_SUN = @"mercury rotation around sun";   // 水星环绕太阳旋转
NSString *const ROTATION_VENUS_AROUND_SUN = @"venus rotation around sun";       // 金星环绕太阳旋转
NSString *const ROTATION_EARTH_AROUND_SUN = @"earth rotation around sun";       // 地球环绕太阳旋转
NSString *const ROTATION_MOON_AROUND_EARTH = @"moon rotation around earth";     // 月球环绕地球旋转
NSString *const ROTATION_MARS_AROUND_SUN = @"mars rotation around sun";         // 火星环绕太阳旋转
NSString *const ROTATION_JUPITER_AROUND_SUN = @"jupiter rotation around sun";   // 木星环绕太阳旋转
NSString *const ROTATION_SATURN_AROUND_SUN = @"saturn rotation around sun";     // 土星环绕太阳旋转
NSString *const ROTATION_URANUS_AROUND_SUN = @"uranus rotation around sun";     // 天王星环绕太阳旋转
NSString *const ROTATION_NEPTUNE_AROUND_SUN = @"neptune rotation around sun";   // 海王星环绕太阳旋转
NSString *const ROTATION_PLUTO_AROUND_SUN = @"pluto rotation around sun";       // 冥王星环绕太阳旋转

@interface ViewController () <ARSCNViewDelegate, ARSessionDelegate>
// AR视图：展示3D界面
@property(nonatomic, strong) ARSCNView *ARSCNView;
// AR会话，负责管理相机追踪配置及3D相机坐标
@property(nonatomic,strong) ARSession *ARSession;
// 会话追踪配置
@property(nonatomic,strong) ARConfiguration *ARSessionConfiguration;
// Node对象
@property(nonatomic, strong) SCNNode *sunNode;          // 太阳
@property(nonatomic, strong) SCNNode *sunHaloNode;      // 日晕
@property(nonatomic, strong) SCNNode *earthNode;        // 地球
@property(nonatomic, strong) SCNNode *earthGroupNode;   // 地球组
@property(nonatomic, strong) SCNNode *moonNode;         // 月球
@property(nonatomic, strong) SCNNode *marsNode;         // 火星
@property(nonatomic, strong) SCNNode *mercuryNode;      // 水星
@property(nonatomic, strong) SCNNode *venusNode;        // 金星
@property(nonatomic, strong) SCNNode *jupiterNode;      // 木星
@property(nonatomic, strong) SCNNode *jupiterLoopNode;  // 木星环
@property(nonatomic, strong) SCNNode *jupiterGroupNode; // 木星组
@property(nonatomic, strong) SCNNode *saturnNode;       // 土星
@property(nonatomic, strong) SCNNode *saturnLoopNode;   // 土星环
@property(nonatomic, strong) SCNNode *sartunGruopNode;  // 土星组
@property(nonatomic, strong) SCNNode *uranusNode;       // 天王星
@property(nonatomic, strong) SCNNode *uranusLoopNode;   // 天王星环
@property(nonatomic, strong) SCNNode *uranusGroupNode;  // 天王星组
@property(nonatomic, strong) SCNNode *neptuneNode;      // 海王星
@property(nonatomic, strong) SCNNode *neptuneLoopNode;  // 海王星环
@property(nonatomic, strong) SCNNode *neptuneGroupNode; // 海王星组
@property(nonatomic, strong) SCNNode *plutoNode;        // 冥王星

@end

    
@implementation ViewController

#pragma mark - 控制器生命周期

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.ARSCNView.delegate = self;                                     // 宣布当前控制器遵从ARSCNViewDelegate协议
    [self.view addSubview:self.ARSCNView];                              // 添加AR视图到当前控制器的子视图中
    [self.ARSession runWithConfiguration:self.ARSessionConfiguration];  // 运行ARSession配置
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.ARSCNView.session pause]; // 当离开当前控制器后，AR会话停止
}

#pragma mark - 接收内存警告

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - 初始化Node

- (void)initNode {
    [self creatPlanets];            // 初始化创建行星对象，并分配内存空间
    [self setNodeGeometry];         // 设置行星的节点几何（球体）并设置半径大小
    [self setVector3];              // 设置行星节点的位置的三分量向量(也称为三维矢量)
    [self addChildNode];            // 添加相应的子节点
    [self setPlanetsOrbit];         // 设置行星轨道
    [self addSpecialEffect];        // 添加特殊效果
    [self setChartlet];             // 设置模型贴图
    [self setEnvironmentAttribute]; // 设置环境属性
    [self makePlanetsAnimation];    // 制作行星动画
    [self setPlanetsRotation];      // 设置行星自转
    [self addLight];                // 添加光源
}

#pragma mark - 创建属性

- (void)creatPlanets {
    _sunNode = [[SCNNode alloc] init];          // 初始化太阳Node，并分配内存空间
    _mercuryNode = [[SCNNode alloc] init];      // 初始化水星Node，并分配内存空间
    _venusNode = [[SCNNode alloc] init];        // 初始化金星Node，并分配内存空间
    _earthNode = [[SCNNode alloc] init];        // 初始化地球Node，并分配内存空间
    _moonNode = [[SCNNode alloc] init];         // 初始化月球Node，并分配内存空间
    _earthGroupNode = [[SCNNode alloc] init];   // 初始化地球组Node，并分配内存空间
    _marsNode = [[SCNNode alloc] init];         // 初始化火星Node，并分配内存空间
    _jupiterNode = [[SCNNode alloc] init];      // 初始化木星Node，并分配内存空间
    _saturnNode = [[SCNNode alloc] init];       // 初始化土星Node，并分配内存空间
    _sartunGruopNode = [[SCNNode alloc] init];  // 初始化土星组Node，并分配内存空间
    _uranusNode = [[SCNNode alloc] init];       // 初始化天王星Node，并分配内存空间
    _neptuneNode = [[SCNNode alloc] init];      // 初始化海王星Node，并分配内存空间
    _plutoNode = [[SCNNode alloc] init];        // 初始化冥王星Node，并分配内存空间
}

#pragma mark - 设置节点几何

- (void)setNodeGeometry {
    _sunNode.geometry = [SCNSphere sphereWithRadius:0.25];      // 设置太阳Node的几何，并设置球体半径
    _mercuryNode.geometry = [SCNSphere sphereWithRadius:0.02];  // 设置水星Node的几何，并设置球体半径
    _venusNode.geometry = [SCNSphere sphereWithRadius:0.04];    // 设置金星Node的几何，并设置球体半径
    _earthNode.geometry = [SCNSphere sphereWithRadius:0.05];    // 设置地球Node的几何，并设置球体半径
    _moonNode.geometry = [SCNSphere sphereWithRadius:0.01];     // 设置月球Node的几何，并设置球体半径
    _marsNode.geometry = [SCNSphere sphereWithRadius:0.03];     // 设置火星Node的几何，并设置球体半径
    _jupiterNode.geometry = [SCNSphere sphereWithRadius:0.15];  // 设置木星Node的几何，并设置球体半径
    _saturnNode.geometry = [SCNSphere sphereWithRadius:0.12];   // 设置土星Node的几何，并设置球体半径
    _uranusNode.geometry = [SCNSphere sphereWithRadius:0.09];   // 设置天王星Node的几何，并设置球体半径
    _neptuneNode.geometry = [SCNSphere sphereWithRadius:0.08];  // 设置海王星Node的几何，并设置球体半径
    _plutoNode.geometry = [SCNSphere sphereWithRadius:0.04];    // 设置冥王星Node的几何，并设置球体半径
}

#pragma mark - 设置行星位置三分量向量（三维矢量）

- (void)setVector3 {
    _sunNode.position = SCNVector3Make(0, -0.1, 3);             // 设置太阳位置三分量向量
    _mercuryNode.position = SCNVector3Make(0.4, 0, 0);          // 设置水星的位置三分量向量
    _venusNode.position = SCNVector3Make(0.6, 0, 0);            // 设置金星的位置三分量向量
    _earthGroupNode.position = SCNVector3Make(0.8, 0, 0);       // 设置地球组的位置三分量向量
    _moonNode.position = SCNVector3Make(0.1, 0, 0);             // 设置月球的位置三分量向量
    _marsNode.position = SCNVector3Make(1.05, 0, 0);            // 设置火星的位置三分量向量
    _jupiterNode.position = SCNVector3Make(1.4, 0, 0);          // 设置木星的位置三分量向量
    _sartunGruopNode.position = SCNVector3Make(1.64, 0, 0);     // 设置土星组的位置三分量向量
    _uranusNode.position = SCNVector3Make(1.915, 0, 0);         // 设置天王星位置三分量向量
    _neptuneNode.position = SCNVector3Make(2.088, 0, 0);        // 设置海王星位置三分量向量
    _plutoNode.position = SCNVector3Make(2.3, 0, 0);            // 设置冥王星位置三分量向量
}

#pragma mark - 添加子节点

- (void)addChildNode {
    [_earthGroupNode addChildNode:_earthNode];              // 将地球节点添加到地球组的子节点中
    [_sartunGruopNode addChildNode:_saturnNode];            // 将土星节点添加到土星组的子节点中
    [self.ARSCNView.scene.rootNode addChildNode:_sunNode];  // 将太阳节点加入到环境的根节点中
}

#pragma mark - 设置行星轨道

- (void)setPlanetsOrbit {
    // 添加一个纹理的平面来表示星球的轨道
    SCNNode *mercuryOrbit = [SCNNode node];                                                     // 初始化水星轨道，并分配内存空间
    mercuryOrbit.opacity = 0.4;                                                                 // 不透明度
    mercuryOrbit.geometry = [SCNBox boxWithWidth:0.86 height:0 length:0.86 chamferRadius:0];    // 设置几何为具有矩形侧面和可选倒角的框，分别表示宽，高，长度和斜切半径。
    mercuryOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;    // 设置几何的主要材质的漫射(指定从表面反射的光量。漫射光在所有方向上都是均匀反射的，因此独立于视点)内容
                                                                                                // 使用发射地图纹理来模拟发光的表面的部分。SceneKit不把材料当作光源，相反，发射属性决定了一种独立于照明的材料的颜色。(为了创建一个看起来发光的对象，你可能希望将一个几何图形和一个发射映射和其他内容结合起来SCNLight对象添加到场景中。默认情况下，发射属性是内容对象是黑色的颜色，导致属性没有可见的效果。将发射属性的内容设置为任何纯色，使材料的颜色与照明的不一致。为了创建一个选择性的发光效果，将属性的内容设置为一个图像或其他纹理映射的内容，它们的发光区域使用明亮的颜色，而其他区域使用较深的颜色。在发射地图的深色部分(以及减少不透明度的部分)，材料的其他视觉属性有助于在场景照明下的出现。下图显示的是一种材料(其质地)扩散属性)在提供一个发射地图图像之前和之后。
    mercuryOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;                // 纹理过滤使用mipmap将材料属性的图像内容以比原始图像的尺寸小的方式呈现。SCNFilterModeLinear从正在采样的坐标附近的纹理过滤样本纹理，并线性内插其颜色
    mercuryOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;           // 统一遮阳，只包含环境照明。
    [_sunNode addChildNode:mercuryOrbit];                                                       // 将水星轨道点添加到太阳节点中区
    
    SCNNode *venusOrbit = [SCNNode node];                                                       // 初始化金星轨道， 并分配内存空间
    venusOrbit.opacity = 0.4;
    venusOrbit.geometry = [SCNBox boxWithWidth:1.29 height:0 length:1.29 chamferRadius:0];
    venusOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    venusOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    venusOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:venusOrbit];
    
    SCNNode *earthOrbit = [SCNNode node];                                                       // 初始化地球轨道， 并分配内存空间
    earthOrbit.opacity = 0.4;
    earthOrbit.geometry = [SCNBox boxWithWidth:1.72 height:0 length:1.72 chamferRadius:0];
    earthOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    earthOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    earthOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:earthOrbit];
    
    SCNNode *marsOrbit = [SCNNode node];                                                        // 初始化火星轨道， 并分配内存空间
    marsOrbit.opacity = 0.4;
    marsOrbit.geometry = [SCNBox boxWithWidth:2.14 height:0 length:2.14 chamferRadius:0];
    marsOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    marsOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    marsOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:marsOrbit];
    
    SCNNode *jupiterOrbit = [SCNNode node];                                                      // 初始化木星轨道， 并分配内存空间
    jupiterOrbit.opacity = 0.4;
    jupiterOrbit.geometry = [SCNBox boxWithWidth:2.95 height:0 length:2.95 chamferRadius:0];
    jupiterOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    jupiterOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    jupiterOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:jupiterOrbit];
    
    SCNNode *saturnOrbit = [SCNNode node];                                                       // 初始化土星轨道， 并分配内存空间
    saturnOrbit.opacity = 0.4;
    saturnOrbit.geometry = [SCNBox boxWithWidth:3.57 height:0 length:3.57 chamferRadius:0];
    saturnOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    saturnOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    saturnOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:saturnOrbit];
    
    SCNNode *uranusOrbit = [SCNNode node];                                                       // 初始化天王星轨道， 并分配内存空间
    uranusOrbit.opacity = 0.4;
    uranusOrbit.geometry = [SCNBox boxWithWidth:4.19 height:0 length:4.19 chamferRadius:0];
    uranusOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    uranusOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    uranusOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:uranusOrbit];
    
    SCNNode *neptuneOrbit = [SCNNode node];                                                       // 初始化海王星轨道， 并分配内存空间
    neptuneOrbit.opacity = 0.4;
    neptuneOrbit.geometry = [SCNBox boxWithWidth:4.54 height:0 length:4.54 chamferRadius:0];
    neptuneOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    neptuneOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    neptuneOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:neptuneOrbit];
    
    SCNNode *pluteOrbit = [SCNNode node];                                                         // 初始化冥王星轨道， 并分配内存空间
    pluteOrbit.opacity = 0.4;
    pluteOrbit.geometry = [SCNBox boxWithWidth:4.98 height:0 length:4.98 chamferRadius:0];
    pluteOrbit.geometry.firstMaterial.diffuse.contents = IMAGE_ORBIT;
    pluteOrbit.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    pluteOrbit.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    [_sunNode addChildNode:pluteOrbit];
}

#pragma mark - 添加特殊效果

- (void)addSpecialEffect {
    //添加土星环
    SCNNode *saturnLoopNode = [SCNNode node];
    saturnLoopNode.opacity = 0.4;
    saturnLoopNode.geometry = [SCNBox boxWithWidth:0.6 height:0 length:0.6 chamferRadius:0];
    saturnLoopNode.geometry.firstMaterial.diffuse.contents = IMAGE_SATURN_LOOP;
    saturnLoopNode.geometry.firstMaterial.diffuse.mipFilter = SCNFilterModeLinear;
    saturnLoopNode.rotation = SCNVector4Make(-0.5, -1, 0, M_PI_2);// 设置土星环的旋转四分量向量，造成倾斜效果
    saturnLoopNode.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant; // 统一遮阳，只包含环境照明。
    [_sartunGruopNode addChildNode:saturnLoopNode];
    
    // 添加地球大气层
    SCNNode *cloudsNode = [SCNNode node];
    cloudsNode.geometry = [SCNSphere sphereWithRadius:0.055];
    [_earthNode addChildNode:cloudsNode];
    cloudsNode.opacity = 0.5;
    cloudsNode.geometry.firstMaterial.transparent.contents = IMAGE_CLOUDSTRANSPARENCY;
    cloudsNode.geometry.firstMaterial.transparencyMode = SCNTransparencyModeRGBZero;// 忽略RGB配色，颜色透明
    
    // 给太阳增加一圈光晕
    _sunHaloNode = [SCNNode node];
    _sunHaloNode.geometry = [SCNPlane planeWithWidth:2.5 height:2.5];
    _sunHaloNode.rotation = SCNVector4Make(1, 0, 0, 0);
    _sunHaloNode.geometry.firstMaterial.diffuse.contents = IMAGE_SUN_HALO;
    _sunHaloNode.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    _sunHaloNode.geometry.firstMaterial.writesToDepthBuffer = NO; // 只是简单的加一层光晕，不需要深度
    _sunHaloNode.opacity = 0.2;
    [_sunNode addChildNode:_sunHaloNode];
}

#pragma mark - 设置贴图

- (void)setChartlet {
    // 水星贴图
    _mercuryNode.geometry.firstMaterial.diffuse.contents = IMAGE_MERCURY;
    // 金星贴图
    _venusNode.geometry.firstMaterial.diffuse.contents = IMAGE_VENUS;
    // 火星贴图
    _marsNode.geometry.firstMaterial.diffuse.contents = IMAGE_MARS;
    // 地球贴图
    // 从光源方向漫射至球体表面，均匀散布开，即迎光面
    _earthNode.geometry.firstMaterial.diffuse.contents = IMAGE_EARTH_DIFFUSE_MINI;
    // 发射特性指定材料发射的光量。这种发射不会照亮场景中的其他表面。自身亮度
    _earthNode.geometry.firstMaterial.emission.contents = IMAGE_EARTH_EMISSIVE;
    // 镜面属性指定光以类似镜子的方式反射。当视线与反射光的方向一致时，镜面强度会增加。背光面
    _earthNode.geometry.firstMaterial.specular.contents = IMAGE_EARTH_SPECULAR_MINI;
    // 月球贴图
    _moonNode.geometry.firstMaterial.diffuse.contents = IMAGE_MOON;
    // 木星贴图
    _jupiterNode.geometry.firstMaterial.diffuse.contents = IMAGE_JUPITER;
    // 土星贴图
    _saturnNode.geometry.firstMaterial.diffuse.contents = IMAGE_SATURN;
    _saturnLoopNode.geometry.firstMaterial.diffuse.contents = IMAGE_SATURN_LOOP;
    // 天王星
    _uranusNode.geometry.firstMaterial.diffuse.contents = IMAGE_URANUS;
    // 海王星
    _neptuneNode.geometry.firstMaterial.diffuse.contents = IMAGE_NEPTUNE;
    // 冥王星
    _plutoNode.geometry.firstMaterial.diffuse.contents = IMAGE_PLUTO;
    // 太阳贴图
    // multiply属性指定用于将输出片段乘以的颜色或图像。计算的片段乘以乘法值以产生最终片段。此属性可用于阴影贴图，淡出或淡化3d对象。
    _sunNode.geometry.firstMaterial.multiply.contents = IMAGE_SUN;
    _sunNode.geometry.firstMaterial.diffuse.contents = IMAGE_SUN;
    // 确定接收机的强度。该强度用于以几种方式调制性质。它使漫反射，镜面和发射特性变暗，它改变了正常属性的颠簸过滤性能与白色混合。默认值为1.0。
    _sunNode.geometry.firstMaterial.multiply.intensity = 0.5;
    _sunNode.geometry.firstMaterial.lightingModelName = SCNLightingModelConstant;
    // 确定接收者的纹理坐标的包装模式。默认为SCNWrapModeClamp
    _sunNode.geometry.firstMaterial.multiply.wrapS =
    _sunNode.geometry.firstMaterial.diffuse.wrapS  =
    _sunNode.geometry.firstMaterial.multiply.wrapT =
    _sunNode.geometry.firstMaterial.diffuse.wrapT  = SCNWrapModeRepeat;// 利用材料将纹理图像贴到表面
}

#pragma mark - 设置环境属性

- (void)setEnvironmentAttribute {
    // 使环境属性自动匹配分散属性, 它决定材料是否与环境和漫射照明相同
    _mercuryNode.geometry.firstMaterial.locksAmbientWithDiffuse =
    _venusNode.geometry.firstMaterial.locksAmbientWithDiffuse =
    _marsNode.geometry.firstMaterial.locksAmbientWithDiffuse =
    _earthNode.geometry.firstMaterial.locksAmbientWithDiffuse =
    _moonNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _jupiterNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _saturnNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _uranusNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _neptuneNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _plutoNode.geometry.firstMaterial.locksAmbientWithDiffuse  =
    _sunNode.geometry.firstMaterial.locksAmbientWithDiffuse   = YES;
    // 亮度，默认是1
    _mercuryNode.geometry.firstMaterial.shininess =
    _venusNode.geometry.firstMaterial.shininess =
    _earthNode.geometry.firstMaterial.shininess =
    _moonNode.geometry.firstMaterial.shininess =
    _marsNode.geometry.firstMaterial.shininess =
    _jupiterNode.geometry.firstMaterial.shininess =
    _saturnNode.geometry.firstMaterial.shininess =
    _uranusNode.geometry.firstMaterial.shininess =
    _neptuneNode.geometry.firstMaterial.shininess =
    _plutoNode.geometry.firstMaterial.shininess = 0.1;
    // 镜面反射强度，这个镜面属性指定光的数量以类似镜子的方式反射。当视线与反射光的方向一致时，镜面强度会增加，对于所有其他属性，降低强度会使物料的内容变暗
    _mercuryNode.geometry.firstMaterial.specular.intensity =
    _venusNode.geometry.firstMaterial.specular.intensity =
    _earthNode.geometry.firstMaterial.specular.intensity =
    _moonNode.geometry.firstMaterial.specular.intensity =
    _marsNode.geometry.firstMaterial.specular.intensity =
    _jupiterNode.geometry.firstMaterial.specular.intensity =
    _saturnNode.geometry.firstMaterial.specular.intensity =
    _uranusNode.geometry.firstMaterial.specular.intensity =
    _neptuneNode.geometry.firstMaterial.specular.intensity =
    _plutoNode.geometry.firstMaterial.specular.intensity =
    _marsNode.geometry.firstMaterial.specular.intensity = 0.5;
    _moonNode.geometry.firstMaterial.specular.contents = [UIColor grayColor];// 设置月球的内容纯色，
}

#pragma mark - 制作行星动画

- (void)makePlanetsAnimation {
    // 月球自转
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 15.0;                                                           // 自转周期, 月球的自转周期和公转相同
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)]; // 四维矢量，沿着y轴做环形运动，其中第一个分量代表轴(控制控件运动角度)，第二个分量代表方向，第三个分量代表镜头远近，最后一个分量代表旋转（弧度）
    animation.repeatCount = FLT_MAX;                                                     // 重复次数，无限
    [_moonNode addAnimation:animation forKey:ROTATION_MOON];
    
    // 月球绕地球旋转的中心
    SCNNode *moonRotationNode = [SCNNode node];
    [moonRotationNode addChildNode:_moonNode];// 将月球节点加入月球旋转节点中
    
    // 地球围绕太阳旋转
    SCNNode *earthRotationNode = [SCNNode node];
    [earthRotationNode addChildNode:_earthGroupNode];// 地球组节点，包括地区和月球
    [_sunNode addChildNode:earthRotationNode];
    
    // 水星围绕太阳旋转
    SCNNode *mercRotationNode = [SCNNode node];
    [mercRotationNode addChildNode:_mercuryNode];
    [_sunNode addChildNode:mercRotationNode];
    
    // 金星围绕太阳旋转
    SCNNode *venusRotationNode = [SCNNode node];
    [venusRotationNode addChildNode:_venusNode];
    [_sunNode addChildNode:venusRotationNode];
    
    // 火星围绕太阳旋转
    SCNNode *marsRotationNode = [SCNNode node];
    [marsRotationNode addChildNode:_marsNode];
    [_sunNode addChildNode:marsRotationNode];
    
    // 木星围绕太阳旋转
    SCNNode *jupiterRotationNode = [SCNNode node];
    [jupiterRotationNode addChildNode:_jupiterNode];
    [_sunNode addChildNode:jupiterRotationNode];
    
    // 土星围绕太阳旋转
    SCNNode *saturnRotationNode = [SCNNode node];
    [saturnRotationNode addChildNode:_sartunGruopNode];
    [_sunNode addChildNode:saturnRotationNode];
    
    // 天王星围绕太阳旋转
    SCNNode *uranusRotationNode = [SCNNode node];
    [uranusRotationNode addChildNode:_uranusNode];
    [_sunNode addChildNode:uranusRotationNode];
    
    // 海王星围绕太阳旋转
    SCNNode *neptuneRotationNode = [SCNNode node];
    [neptuneRotationNode addChildNode:_neptuneNode];
    [_sunNode addChildNode:neptuneRotationNode];
    
    // 冥王星围绕太阳旋转
    SCNNode *plutoRotationNode = [SCNNode node];
    [plutoRotationNode addChildNode:_plutoNode];
    [_sunNode addChildNode:plutoRotationNode];
    
    // 统一设置对应动画
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 25.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [mercRotationNode addAnimation:animation forKey:ROTATION_MERCURY_AROUND_SUN];
    [_sunNode addChildNode:mercRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 40.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [venusRotationNode addAnimation:animation forKey:ROTATION_VENUS_AROUND_SUN];
    [_sunNode addChildNode:venusRotationNode];
    
    // 制作地球围绕太阳旋转的动画
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 30.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [earthRotationNode addAnimation:animation forKey:ROTATION_EARTH_AROUND_SUN];
    
    // 月球围绕地球进行旋转
    CABasicAnimation *moonRotationAnimation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    moonRotationAnimation.duration = 15.0;// 公转周期
    moonRotationAnimation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    moonRotationAnimation.repeatCount = FLT_MAX;
    [moonRotationNode addAnimation:animation forKey:ROTATION_MOON_AROUND_EARTH];
    [_earthGroupNode addChildNode:moonRotationNode];// 将月球旋转节点添加到地球组节点的子节点中
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 35.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [marsRotationNode addAnimation:animation forKey:ROTATION_MARS_AROUND_SUN];
    [_sunNode addChildNode:marsRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 90.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [jupiterRotationNode addAnimation:animation forKey:ROTATION_JUPITER_AROUND_SUN];
    [_sunNode addChildNode:jupiterRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 80.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [saturnRotationNode addAnimation:animation forKey:ROTATION_SATURN_AROUND_SUN];
    [_sunNode addChildNode:saturnRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 55.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [uranusRotationNode addAnimation:animation forKey:ROTATION_URANUS_AROUND_SUN];
    [_sunNode addChildNode:uranusRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 50.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [neptuneRotationNode addAnimation:animation forKey:ROTATION_NEPTUNE_AROUND_SUN];
    [_sunNode addChildNode:neptuneRotationNode];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_ROTATION_KEY];
    animation.duration = 100.0;
    animation.toValue = [NSValue valueWithSCNVector4:SCNVector4Make(0, 1, 0, M_PI * 2)];
    animation.repeatCount = FLT_MAX;
    [plutoRotationNode addAnimation:animation forKey:ROTATION_PLUTO_AROUND_SUN];
    [_sunNode addChildNode:plutoRotationNode];
    
    // 添加太阳动画
    [self setAnimationToSun];
}

#pragma mark - 设置太阳动画

- (void)setAnimationToSun{
    // 通过动画纹理来达到熔岩的效果(变形动画)
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:ANIMATION_CONTENTSTRANSFORM_KEY];
    animation.duration = 10.0;
    // 定义在核心动画中使用的标准转换矩阵。
    animation.fromValue = [NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DMakeTranslation(0, 0, 0), CATransform3DMakeScale(3, 3, 3))];
    animation.toValue = [NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DMakeTranslation(1, 0, 0), CATransform3DMakeScale(3, 3, 3))];
    animation.repeatCount = FLT_MAX;
    // 将该动画从光源方向漫射至球体表面，均匀散布开
    [_sunNode.geometry.firstMaterial.diffuse addAnimation:animation forKey:ANIMATION_SUN_TEXTURE];
    
    animation = [CABasicAnimation animationWithKeyPath:ANIMATION_CONTENTSTRANSFORM_KEY];
    animation.duration = 30.0;
    animation.fromValue = [NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DMakeTranslation(0, 0, 0), CATransform3DMakeScale(5, 5, 5))];
    animation.toValue = [NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DMakeTranslation(1, 0, 0), CATransform3DMakeScale(5, 5, 5))];
    animation.repeatCount = FLT_MAX;
    // 3D对象着色
    [_sunNode.geometry.firstMaterial.multiply addAnimation:animation forKey:ANIMATION_SUN_COLORING];
}

#pragma mark - 设置行星自转

- (void)setPlanetsRotation {
    [_mercuryNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];    // 水星自转
    [_venusNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];      // 金星自转
    [_earthNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];      // 地球自转
    [_marsNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];       // 火星自转
    [_jupiterNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];    // 木星自转
    [_saturnNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];     // 土星自转
    [_uranusNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];     // 天王星自转
    [_neptuneNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];    // 海王星自转
    [_plutoNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:0 y:2 z:0 duration:1.0]]];      // 冥王星自转
}

#pragma mark - 添加光源

- (void)addLight {
    // 将现场所有光源都关掉，然后添加一盏新的光源，即太阳，会造成一种太阳点亮了整个太阳系的错觉
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.color = [UIColor blackColor]; // 关闭所有光源
    lightNode.light.type = SCNLightTypeOmni;      // 全向光，也叫点光。由于全向光在各个方向上都有相等的光照，所以含有光的节点的方向没有影响。聚光灯的角度和阴影属性不适用于定向光。
    [_sunNode addChildNode:lightNode];            // 将光源添加到太阳上

    // 配置衰减距离, 不然会把底部也照亮，这不是应有的效果
    lightNode.light.attenuationEndDistance = 19;
    lightNode.light.attenuationStartDistance = 21;
    
    // 动画效果
    [SCNTransaction begin];
    [SCNTransaction setAnimationDuration:1];
    {
        lightNode.light.color = [UIColor whiteColor]; //  开灯
        _sunHaloNode.opacity = 0.5;                   // 让光环更强大
    }
    [SCNTransaction commit];                          // 委派执行
}

#pragma mark - AR会话配置(懒加载)

- (ARConfiguration *)ARSessionConfiguration {
    if (!_ARSessionConfiguration) {
        ARWorldTrackingConfiguration *configuration = [[ARWorldTrackingConfiguration alloc] init];  // 创建世界追踪会话配置
        configuration.planeDetection = ARPlaneDetectionHorizontal;                                  // 设置追踪方向，追踪平面
        _ARSessionConfiguration = configuration;
        _ARSessionConfiguration.lightEstimationEnabled = YES;                                       // 自适应灯光（相机从暗到强光快速过渡效果会平缓一些）
    }
    return _ARSessionConfiguration;
}

- (ARSession *)ARSession {
    if (!_ARSession) {
        _ARSession = [[ARSession alloc] init];
        _ARSession.delegate = self;// 遵循ARSession协议
    }
    return _ARSession;
}

- (ARSCNView *)ARSCNView {
    if (!_ARSCNView) {
        _ARSCNView = [[ARSCNView alloc] initWithFrame:self.view.bounds];
        _ARSCNView.session = self.ARSession;
        _ARSCNView.automaticallyUpdatesLighting = YES;  // 开启自动调节光源
        _ARSCNView.delegate = self;                     // 遵循ARSCNView协议
        [self initNode];                                // 初始化节点
    }
    return _ARSCNView;
}

#pragma mark - 会话位置更新(ARSessionDelegate)

- (void)session:(ARSession *)session didUpdateFrame:(ARFrame *)frame
{
    //监听手机的移动，实现近距离查看太阳系细节，为了凸显效果变化值*3
    [_sunNode setPosition:SCNVector3Make(-3 * frame.camera.transform.columns[3].x, -0.1 - 3 * frame.camera.transform.columns[3].y, -2 - 3 * frame.camera.transform.columns[3].z)];
}

@end
