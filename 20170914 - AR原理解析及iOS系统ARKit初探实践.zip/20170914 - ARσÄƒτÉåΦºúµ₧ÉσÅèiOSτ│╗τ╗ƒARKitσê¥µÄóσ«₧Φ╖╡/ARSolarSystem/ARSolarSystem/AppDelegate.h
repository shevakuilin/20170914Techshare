//
//  AppDelegate.h
//  ARSolarSystem
//
//  Created by ShevaKuilin on 2017/9/11.
//  Copyright © 2017年 ShevaKuilin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

